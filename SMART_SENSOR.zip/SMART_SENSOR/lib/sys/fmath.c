/**
 * Math functions
 * author: Guillaume Patrigeon
 * update: 02-01-2019
 */

#include "fmath.h"



float rsqrtf(float x)
{
	unsigned long* i = (unsigned long*)&x;
	float f = 0.5*x;

	*i = 0x5F3759DF - (*i >> 1);
	x = x*(1.5f - f*x*x);

	return x;
}


float sinf(float x)
{
	float f;

	while (x < -PI)
		x += PIx2;

	while (x > PI)
    	x -= PIx2;

	if (x < 0)
		f = 1.27323954f * x + 0.405284735f * x * x;
	else
		f = 1.27323954f * x - 0.405284735f * x * x;

	if (f < 0)
		f = 0.225f * (f *-f - f) + f;
	else
		f = 0.225f * (f * f - f) + f;

	return f;
}


float acosf(float x) {
	float negate = (float)(x < 0);
	x = absf(x);
	float ret = -0.0187293f;
	ret = ret * x;
	ret = ret + 0.0742610f;
	ret = ret * x;
	ret = ret - 0.2121144f;
	ret = ret * x;
	ret = ret + 1.5707288f;
	ret = ret * sqrtf(1.0-x);
	ret = ret - 2 * negate * ret;
	return negate * 3.141592654f + ret;
}


float atan2f(float y, float x)
{
	float t0, t1, t3, t4;

	t3 = absf(x);
	t1 = absf(y);
	t0 = max(t3, t1);
	t1 = min(t3, t1);
	t3 = 1.f / t0;
	t3 = t1 * t3;

	t4 = t3 * t3;
	t0 =         - 0.013480470f;
	t0 = t0 * t4 + 0.057477314f;
	t0 = t0 * t4 - 0.121239071f;
	t0 = t0 * t4 + 0.195635925f;
	t0 = t0 * t4 - 0.332994597f;
	t0 = t0 * t4 + 0.999995630f;
	t3 = t0 * t3;

	t3 = (absf(y) > absf(x)) ? 1.570796327f - t3 : t3;
	t3 = (x < 0) ? 3.141592654f - t3 : t3;
	t3 = (y < 0) ? -t3 : t3;

	return t3;
}
