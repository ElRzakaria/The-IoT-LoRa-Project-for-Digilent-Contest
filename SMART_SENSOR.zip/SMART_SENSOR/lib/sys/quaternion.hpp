/**
 * C++ Quaternion library
 * author: Guillaume Patrigeon
 * update: 05-01-2018
 */

#ifndef __QUATERNION_HPP__
#define __QUATERNION_HPP__



struct Quaternion
{
	float a;
	float b;
	float c;
	float d;


	Quaternion(void);
	Quaternion(float a);
	Quaternion(float a, float b, float c, float d);

	float mod(void);

	void mod(float m);

	Quaternion& operator=(float other);

	Quaternion operator+(void) const;
	Quaternion operator-(void) const;
	Quaternion operator~(void) const;

	Quaternion operator+(float other) const;
	Quaternion operator+(const Quaternion& other) const;

	Quaternion& operator+=(float other);
	Quaternion& operator+=(const Quaternion& other);

	Quaternion operator-(float other) const;
	Quaternion operator-(const Quaternion& other) const;

	Quaternion& operator-=(float other);
	Quaternion& operator-=(const Quaternion& other);

	Quaternion operator*(float other) const;
	Quaternion operator*(const Quaternion& other) const;

	Quaternion& operator*=(float other);
	Quaternion& operator*=(const Quaternion& other);

	Quaternion operator/(float other) const;
	Quaternion operator/(const Quaternion& other) const;

	Quaternion& operator/=(float other);
	Quaternion& operator/=(const Quaternion& other);
};



Quaternion operator+(float f, const Quaternion& other);
Quaternion operator-(float f, const Quaternion& other);
Quaternion operator*(float f, const Quaternion& other);
Quaternion operator/(float f, const Quaternion& other);



// ===========================================================================
inline Quaternion::Quaternion(void):
    a(0.f),
    b(0.f),
    c(0.f),
    d(0.f)
{
}


inline Quaternion::Quaternion(float a):
    a(a),
    b(0.f),
    c(0.f),
    d(0.f)
{
}


inline Quaternion::Quaternion(float a, float b, float c, float d):
    a(a),
    b(b),
    c(c),
    d(d)
{
}



inline float Quaternion::mod(void)
{
	return sqrtf(this->a * this->a + this->b * this->b + this->c * this->c + this->d * this->d);
}


inline void Quaternion::mod(float m)
{
    // float f = m / this->mod();
	float f = m * rsqrtf(this->a * this->a + this->b * this->b + this->c * this->c + this->d * this->d);

	this->a *= f;
	this->b *= f;
	this->c *= f;
	this->d *= f;
}


inline Quaternion& Quaternion::operator=(float other)
{
    this->a = other;
    this->b = 0.f;
    this->c = 0.f;
    this->d = 0.f;

	return *this;
}


inline Quaternion Quaternion::operator+(void) const
{
	return *this;
}


inline Quaternion Quaternion::operator-(void) const
{
	return Quaternion(-this->a, -this->b, -this->c, -this->d);
}


inline Quaternion Quaternion::operator~(void) const
{
	return Quaternion(this->a, -this->b, -this->c, -this->d);
}


inline Quaternion Quaternion::operator+(float other) const
{
	return Quaternion(this->a + other, this->b, this->c, this->d);
}


inline Quaternion Quaternion::operator+(const Quaternion& other) const
{
	return Quaternion(this->a + other.a, this->b + other.b, this->c + other.c, this->d + other.d);
}


inline Quaternion& Quaternion::operator+=(float other)
{
	this->a += other;
	return *this;
}


inline Quaternion& Quaternion::operator+=(const Quaternion& other)
{
	this->a += other.a;
	this->b += other.b;
	this->c += other.c;
	this->d += other.d;
	return *this;
}


inline Quaternion Quaternion::operator-(float other) const
{
	return Quaternion(this->a - other, this->b, this->c, this->d);
}


inline Quaternion Quaternion::operator-(const Quaternion& other) const
{
	return Quaternion(this->a - other.a, this->b - other.b, this->c - other.c, this->d - other.d);
}


inline Quaternion& Quaternion::operator-=(float other)
{
	this->a -= other;
	return *this;
}


inline Quaternion& Quaternion::operator-=(const Quaternion& other)
{
	this->a -= other.a;
	this->b -= other.b;
	this->c -= other.c;
	this->d -= other.d;
	return *this;
}


inline Quaternion Quaternion::operator*(float other) const
{
	return Quaternion(this->a * other, this->b * other, this->c * other, this->d * other);
}


inline Quaternion Quaternion::operator*(const Quaternion& other) const
{
	return Quaternion(this->a*other.a - this->b*other.b - this->c*other.c - this->d*other.d,
	                  this->a*other.b + this->b*other.a + this->c*other.d - this->d*other.c,
					  this->a*other.c + this->c*other.a + this->d*other.b - this->b*other.d,
					  this->a*other.d + this->d*other.a + this->b*other.c - this->c*other.b);
}


inline Quaternion& Quaternion::operator*=(float other)
{
	this->a *= other;
	this->b *= other;
	this->c *= other;
	this->d *= other;
	return *this;
}


inline Quaternion& Quaternion::operator*=(const Quaternion& other)
{
	Quaternion q = (*this) * other;
	this->a = q.a;
	this->b = q.b;
	this->c = q.c;
	this->d = q.d;
	return *this;
}


inline Quaternion Quaternion::operator/(float other) const
{
	return Quaternion(this->a / other, this->b / other, this->c / other, this->d / other);
}


inline Quaternion Quaternion::operator/(const Quaternion& other) const
{
	return ((*this) * ~other)/(other.a*other.a + other.b*other.b + other.c*other.c + other.d*other.d);
}


inline Quaternion& Quaternion::operator/=(float other)
{
	this->a /= other;
	this->b /= other;
	this->c /= other;
	this->d /= other;
	return *this;
}


inline Quaternion& Quaternion::operator/=(const Quaternion& other)
{
	Quaternion q = (*this) / other;
	this->a = q.a;
	this->b = q.b;
	this->c = q.c;
	this->d = q.d;
	return *this;
}



inline Quaternion operator+(float f, const Quaternion& other)
{
	return other + f;
}


inline Quaternion operator-(float f, const Quaternion& other)
{
	return -other + f;
}


inline Quaternion operator*(float f, const Quaternion& other)
{
	return other * f;
}


inline Quaternion operator/(float f, const Quaternion& other)
{
	Quaternion q(f);
	return q / other;
}



#endif
