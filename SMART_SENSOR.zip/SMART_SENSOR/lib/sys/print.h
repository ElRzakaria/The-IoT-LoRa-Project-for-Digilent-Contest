/**
 * author: Guillaume Patrigeon
 * update: 15-02-2018
 */

#ifndef __PRINT_H__
#define __PRINT_H__

#ifdef __cplusplus
extern "C" {
#endif



/// Output stream type
typedef void (*ostream)(const char);


/**
 * Build a formatted text and send it to the output stream
 * Supported format specifiers:
 * - %c:   character
 * - %s:   string of characters
 * - %d:   signed integer
 * - %i:   signed integer
 * - %u:   unsigned integer
 * - %l:   signed long integer
 * - %lu:  unsigned long integer
 * - %ll:  signed long long integer
 * - %llu: unsigned long long integer
 * - %x:   unsigned integer in hexadecimal format (lower case)
 * - %X:   unsigned integer in hexadecimal format (upper case)
 */
void print(ostream output, const char* str, ...);



#ifdef __cplusplus
}
#endif

#endif
