/**
 * Math functions
 * author: Guillaume Patrigeon
 * update: 05-01-2019
 */

#ifndef __FMATH_H__
#define	__FMATH_H__

#ifdef __cplusplus
extern "C" {
#endif

#define PI                      3.141592654f
#define PIx2                    6.283285307f
#define PIdiv2                  1.570796327f
#define PIxPI                   9.869604401f

#define min(a, b)               (((a) > (b)) ? (b) : (a))
#define max(a, b)               (((a) < (b)) ? (b) : (a))



#define abs(x)                  (((x) < 0) ? -(x) : (x))
float absf(float x);

float rsqrtf(float x);
#define sqrtf(x)                (1.f / rsqrtf(x))

float sinf(float x);
#define cosf(x)                 sinf(x + PIdiv2)

float acosf(float x);
float atan2f(float y, float x);



inline float absf(float x) { long r = *((long*)&x) & 0x7FFFFFFF; return *((float*)&r); }



#ifdef __cplusplus
}
#endif

#endif
