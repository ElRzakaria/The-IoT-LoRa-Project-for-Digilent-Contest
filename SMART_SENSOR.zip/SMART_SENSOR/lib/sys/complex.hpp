/**
 * author: Guillaume Patrigeon
 * update: 09-08-2017
 */

#ifndef __COMPLEX_HPP__
#define	__COMPLEX_HPP__



struct Complex
{
	float Re;
	float Im;


	Complex(void);
	Complex(float re);
	Complex(float re, float im);

	float mod(void) const;
	float arg(void) const;

	void mod(float m);
	void arg(float a);

	Complex& operator=(float other);

	Complex operator+(void) const;
	Complex operator-(void) const;
	Complex operator~(void) const;

	Complex operator+(float other) const;
	Complex operator+(const Complex& other) const;

	Complex& operator+=(float other);
	Complex& operator+=(const Complex& other);

	Complex operator-(float other) const;
	Complex operator-(const Complex& other) const;

	Complex& operator-=(float other);
	Complex& operator-=(const Complex& other);

	Complex operator*(float other) const;
	Complex operator*(const Complex& other) const;

	Complex& operator*=(float other);
	Complex& operator*=(const Complex& other);

	Complex operator/(float other) const;
	Complex operator/(const Complex& other) const;

	Complex& operator/=(float other);
	Complex& operator/=(const Complex& other);
};



Complex ComplexFromPolar(float m, float a);



Complex operator+(float f, const Complex& other);
Complex operator-(float f, const Complex& other);
Complex operator*(float f, const Complex& other);
Complex operator/(float f, const Complex& other);



// ===========================================================================
inline Complex::Complex(void):
	Re(0.f),
	Im(0.f)
{
}


inline Complex::Complex(float re):
	Re(re),
	Im(0.f)
{
}


inline Complex::Complex(float re, float im):
	Re(re),
	Im(im)
{
}



inline float Complex::mod(void) const
{
	return sqrtf(this->Re * this->Re + this->Im * this->Im);
}


inline float Complex::arg(void) const
{
	return atan2f(this->Im, this->Re);
}


inline void Complex::mod(float m)
{
    float f = m / this->mod();

	this->Re *= f;
	this->Im *= f;
}


inline void Complex::arg(float a)
{
    float m = this->mod();

	this->Re = m * cosf(a);
	this->Im = m * sinf(a);
}


inline Complex& Complex::operator=(float other)
{
	this->Re = other;
	this->Im = 0.f;

	return *this;
}


inline Complex Complex::operator+(void) const
{
	return *this;
}


inline Complex Complex::operator-(void) const
{
	return Complex(-this->Re, -this->Im);
}


inline Complex Complex::operator~(void) const
{
	return Complex(this->Re, -this->Im);
}


inline Complex Complex::operator+(float other) const
{
	return Complex(this->Re + other, this->Im);
}


inline Complex Complex::operator+(const Complex& other) const
{
	return Complex(this->Re + other.Re, this->Im + other.Im);
}


inline Complex& Complex::operator+=(float other)
{
	this->Re += other;

	return *this;
}


inline Complex& Complex::operator+=(const Complex& other)
{
	this->Re += other.Re;
	this->Im += other.Im;

	return *this;
}


inline Complex Complex::operator-(float other) const
{
	return Complex(this->Re - other, this->Im);
}


inline Complex Complex::operator-(const Complex& other) const
{
	return Complex(this->Re - other.Re, this->Im - other.Im);
}


inline Complex& Complex::operator-=(float other)
{
	this->Re -= other;

	return *this;
}


inline Complex& Complex::operator-=(const Complex& other)
{
	this->Re -= other.Re;
	this->Im -= other.Im;

	return *this;
}


inline Complex Complex::operator*(float other) const
{
	return Complex(this->Re * other, this->Im * other);
}


inline Complex Complex::operator*(const Complex& other) const
{
	return Complex(this->Re * other.Re - this->Im * other.Im,
					this->Im * other.Re + this->Re * other.Im);
}


inline Complex& Complex::operator*=(float other)
{
	this->Re *= other;
	this->Im *= other;

	return *this;
}


inline Complex& Complex::operator*=(const Complex& other)
{
	float f = this->Re * other.Re - this->Im * other.Im;

	this->Im = this->Im * other.Re + this->Re * other.Im;
	this->Re = f;

	return *this;
}


inline Complex Complex::operator/(float other) const
{
	return Complex(this->Re / other, this->Im / other);
}


inline Complex Complex::operator/(const Complex& other) const
{
	float n = other.Re * other.Re + other.Im * other.Im;

	return (*this * ~other)/n;
}


inline Complex& Complex::operator/=(float other)
{
	this->Re /= other;
	this->Im /= other;

	return *this;
}


inline Complex& Complex::operator/=(const Complex& other)
{
	float n = other.Re * other.Re + other.Im * other.Im;

	*this = (*this * ~other)/n;

	return *this;
}



inline Complex ComplexFromPolar(float m, float a)
{
	return Complex(m * cosf(a), m * sinf(a));
}




inline Complex operator+(float f, const Complex& other)
{
	return other + f;
}


inline Complex operator-(float f, const Complex& other)
{
	return -other + f;
}


inline Complex operator*(float f, const Complex& other)
{
	return other * f;
}


inline Complex operator/(float f, const Complex& other)
{
	Complex q(f);
	return q / other;
}



#endif
