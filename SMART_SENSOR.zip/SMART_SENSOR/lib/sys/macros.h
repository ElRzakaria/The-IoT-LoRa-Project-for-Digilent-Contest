/**
 * author: Guillaume Patrigeon
 * update: 24-03-2017
 */

#ifndef __MACROS_H__
#define	__MACROS_H__



/// Get the absolute value of a number
#define _abs(x)                 (((x) < 0) ? -(x) : (x))


/// Get the size of a type
#define _sizeof(type)           ((void*)&(((type*)0)[1]))


/// Get the offset of member in a structure
#define _offsetof(st, m)        ((void*)&(((st*)0)->m))


/// Preprocessor paste (2 items)
#define _PASTE2(a, b)           a ## b


/// Preprocessor paste (3 items)
#define _PASTE3(a, b, c)        a ## b ## c


/// Preprocessor paste (4 items)
#define _PASTE4(a, b, c, d)     a ## b ## c ## d



#endif
