/**
 * Dynamic memory allocation
 * author: Guillaume Patrigeon
 * update: 03-01-2019
 */

#ifndef __ALLOCATE_H__
#define	__ALLOCATE_H__

#ifdef __cplusplus
extern "C" {
#endif



/// Initialize allocation table, must be called first, start alligned
void AllocateInit(void* start, int size);


/// Allocate a partition of memory, return null if failed
void* Allocate(int size);


/// Release an allocated partition of memory
void Release(void* address);


/// Release all allocated partitions (full erase)
void ReleaseAll(void);



#ifdef __cplusplus
}

inline void* operator new(size_t size) { return Allocate(size); }
inline void* operator new[](size_t size) { return Allocate(size); }
inline void operator delete(void* address, size_t size) { Release(address); }
inline void operator delete[](void* address, size_t size) { Release(address); }
#endif

#endif
