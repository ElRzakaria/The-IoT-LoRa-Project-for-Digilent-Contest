/**
 * Dynamic memory allocation
 * author: Guillaume Patrigeon
 * update: 03-01-2019
 */

#include "allocate.h"


// ---------------------------------------------------------------------------
static int* _start = 0;
static int _size = 0;


// ---------------------------------------------------------------------------
void AllocateInit(void* start, int size)
{
	_start = (int*)start;
	_size = size / sizeof(int);

	*_start = _size;
}



// ---------------------------------------------------------------------------
void* Allocate(int size)
{
	int p = 0;

	size = 1 + (size+sizeof(int)-1)/sizeof(int);

	do
	{
		if (_start[p] < 0)
			p -= _start[p];
		else if (_start[p] < size)
			p += _start[p];
		else
			break;
	} while (p < _size);

	if (p >= _size || p + size > _size)
		return 0;

	if (size < _start[p])
		_start[p+size] = _start[p]-size;

	_start[p] = -size;

	return &_start[p+1];
}


// ---------------------------------------------------------------------------
void Release(void* address)
{
	int p = (int*)address - _start - 1;

	if (p < 0 || p >= _size || _start[p] > 0)
		return;

	_start[p] = -_start[p];

	if (p + _start[p] < _size && _start[p+_start[p]] > 0)
		_start[p] += _start[p+_start[p]];

	if (_start[p] > _size - p)
		_start[p] = _size - p;
}


// ---------------------------------------------------------------------------
void ReleaseAll(void)
{
	*_start = _size;
}
