/**
 * author: Guillaume Patrigeon
 * update: 15-02-2017
 */

#ifndef __TYPES_H__
#define	__TYPES_H__



#ifndef size_t
typedef unsigned int size_t;
#endif

#ifndef clock_t
typedef int clock_t;
#endif

#ifndef uint8_t
typedef unsigned char uint8_t;
#endif
#ifndef uint16_t
typedef unsigned short uint16_t;
#endif
#ifndef uint32_t
typedef unsigned int uint32_t;
#endif
#ifndef uint64_t
typedef unsigned long long uint64_t;
#endif

#ifndef int8_t
typedef signed char int8_t;
#endif
#ifndef int16_t
typedef signed short int16_t;
#endif
#ifndef int32_t
typedef signed int int32_t;
#endif
#ifndef int64_t
typedef signed long long int64_t;
#endif

#ifndef bool
typedef enum {false, true} bool;
#endif



#endif
