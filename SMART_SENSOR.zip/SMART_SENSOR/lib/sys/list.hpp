/**
 * author: Guillaume Patrigeon
 * update: 07-01-2019
 */

#ifndef __LIST_HPP__
#define __LIST_HPP__


// ---------------------------------------------------------------------------
template <typename T>
class List
{
private:
	struct List_t
	{
		List_t* prev;
		List_t* next;
		T object;
	};

public:
	class iterator;
	friend class iterator;

	List(void);
	~List(void);

	void clean(void);
	int size(void);

	iterator& first(void);
	iterator& last(void);
	iterator& remove(iterator& it);

	bool operator>>(T& object);

	List& operator<<(const T& object);
	List& operator<<(iterator& it);
	List& operator<<(List& other);


private:
	int _count;
	List_t* _first;
	List_t* _last;
	iterator _itFirst;
	iterator _itLast;
};


// ---------------------------------------------------------------------------
template <typename T>
class List<T>::iterator
{
public:
	iterator(void);
	~iterator(void);

	iterator& remove(void);

	T& operator=(const T& object);
	iterator& operator=(iterator& other);

	T& operator*(void);

	bool operator==(iterator& other);
	bool operator!=(iterator& other);

	iterator& operator++(void);
	iterator& operator++(int dummy);

	iterator& operator--(void);
	iterator& operator--(int dummy);


private:
	friend class List;

	List* _list;
	List_t* _pt;
};


// ---------------------------------------------------------------------------
template <typename T>
inline List<T>::List(void):
	_count(0),
	_first(new List_t),
	_last(this->_first)
{
	this->_last->prev = 0;
	this->_last->next = 0;

	this->_itFirst._list = this;
	this->_itLast._list = this;
	this->_itLast._pt = this->_last;
}


template <typename T>
inline List<T>::~List(void)
{
	this->clean();

	delete this->_last;
}


template <typename T>
inline void List<T>::clean(void)
{
	List_t* tmp;

	while (this->_first != this->_last)
	{
		tmp = this->_first;
		this->_first = this->_first->next;

		delete tmp;
	}

	this->_count = 0;
}


template <typename T>
inline int List<T>::size(void)
{
	return this->_count;
}


template <typename T>
inline typename List<T>::iterator& List<T>::first(void)
{
	this->_itFirst._pt = this->_first;

	return this->_itFirst;
}


template <typename T>
inline typename List<T>::iterator& List<T>::last(void)
{
	return this->_itLast;
}


template <typename T>
inline typename List<T>::iterator& List<T>::remove(iterator& it)
{
	List_t* tmp = it._pt;

	if (tmp == this->_first)
	{
		this->_first = tmp->next;
		this->_first->prev = 0;

		it._pt = this->_first;
	}
	else
	{
		tmp->next->prev = tmp->prev;
		tmp->prev->next = tmp->next;

		it._pt = tmp->next;
	}

	delete tmp;
	this->_count--;

	return it;
}


template <typename T>
inline bool List<T>::operator>>(T& object)
{
	List_t* tmp = this->_first;

	if (this->_first == this->_last)
		return false;

	this->_first = tmp->next;
	this->_first->prev = 0;

	object = tmp->object;

	delete tmp;
	this->_count--;
	return true;
}


template <typename T>
inline List<T>& List<T>::operator<<(const T& object)
{
	List_t* tmp = new List_t;

	tmp->object = object;

	tmp->next = this->_last;
	tmp->prev = this->_last->prev;
	this->_last->prev = tmp;

	if (this->_first == this->_last)
		this->_first = tmp;
	else
		tmp->prev->next = tmp;

	this->_count++;
	return *this;
}


template <typename T>
inline List<T>& List<T>::operator<<(iterator& it)
{
    List_t* tmp = it._pt;
    List* other = it._list;

	if (tmp == other->_first)
	{
		other->_first = tmp->next;
		other->_first->prev = 0;

		it._pt = other->_first;
	}
	else
	{
		tmp->next->prev = tmp->prev;
		tmp->prev->next = tmp->next;

		it._pt = tmp->next;
	}

	tmp->next = this->_last;
	tmp->prev = this->_last->prev;
	this->_last->prev = tmp;

	if (this->_first == this->_last)
		this->_first = tmp;
	else
		tmp->prev->next = tmp;

	other->_count--;
	this->_count++;

	return *this;
}


template <typename T>
inline List<T>& List<T>::operator<<(List& other)
{
    if (!other._count)
        return *this;

    if (!this->_count)
    {
        this->_count = other._count;
        this->_first = other._first;
        this->_last->prev = other._last->prev;

        if (this->_last->prev)
            this->_last->prev->next = this->_last;

        other._first = other._last;
        other._last->prev = 0;
        other._count = 0;

        return *this;
    }

    this->_count += other._count;
	this->_last->prev->next = other._first;
	this->_last->prev->next->prev = this->_last->prev;

	this->_last->prev = other._last->prev;
	this->_last->prev->next = this->_last;

	other._first = other._last;
    other._last->prev = 0;
    other._count = 0;

	return *this;
}


// ---------------------------------------------------------------------------
template <typename T>
inline List<T>::iterator::iterator(void):
	_list(0),
	_pt(0)
{
}


template <typename T>
inline List<T>::iterator::~iterator(void)
{
}


template <typename T>
inline typename List<T>::iterator& List<T>::iterator::remove(void)
{
	return this->_list->remove(*this);
}


template <typename T>
inline T& List<T>::iterator::operator=(const T& object)
{
	this->_pt->object = object;

	return object;
}


template <typename T>
inline typename List<T>::iterator& List<T>::iterator::operator=(iterator& other)
{
	this->_list = other._list;
	this->_pt = other._pt;

	return *this;
}


template <typename T>
inline T& List<T>::iterator::operator*(void)
{
	return this->_pt->object;
}


template <typename T>
inline bool List<T>::iterator::operator==(iterator& other)
{
	return this->_pt == other._pt;
}


template <typename T>
inline bool List<T>::iterator::operator!=(iterator& other)
{
	return this->_pt != other._pt;
}


template <typename T>
inline typename List<T>::iterator& List<T>::iterator::operator++(void)
{
	if (this->_pt->next)
		this->_pt = this->_pt->next;

	return *this;
}


template <typename T>
inline typename List<T>::iterator& List<T>::iterator::operator++(int)
{
	if (this->_pt->next)
		this->_pt = this->_pt->next;

	return *this;
}


template <typename T>
inline typename List<T>::iterator& List<T>::iterator::operator--(void)
{
	if (this->_pt->prev)
		this->_pt = this->_pt->prev;

	return *this;
}


template <typename T>
inline typename List<T>::iterator& List<T>::iterator::operator--(int)
{
	if (this->_pt->prev)
		this->_pt = this->_pt->prev;

	return *this;
}



#endif
