/**
 * author: Guillaume Patrigeon
 * update: 26-01-2018
 */

#ifndef __ARCH_RSTCLK_H__
#define __ARCH_RSTCLK_H__



typedef enum
{
	MEMSEL_ROM1,
	MEMSEL_RAM1
} MEMSEL_e;


typedef struct
{
	union
	{
		volatile unsigned int RSTSTATUS;        // Reset status register

		struct
		{
			volatile unsigned int PWRRST:1;     // Power Reset
			volatile unsigned int HARDRST:1;    // Hard Reset
			volatile unsigned int WDRST:1;      // Watchdog Reset
			volatile unsigned int SOFTRST:1;    // Software Reset
			volatile unsigned int :28;
		};
	};

	union
	{
		volatile unsigned int BOOTOPT;          // Boot option

		struct
		{
			volatile unsigned int MEMSEL:2;     // Memory selection (see BOOTMEM_xxx)
			volatile unsigned int BOOTMEM:2;    // Memory used for boot
			volatile unsigned int :28;
		};
	};
} RSTCLK_t;



#endif
