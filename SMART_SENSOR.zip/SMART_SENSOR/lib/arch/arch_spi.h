/**
 * author: Guillaume Patrigeon
 * update: 05-11-2018
 */

#ifndef __ARCH_SPI_H__
#define __ARCH_SPI_H__



typedef struct
{
	volatile unsigned int DATA;

	union
	{
		const volatile unsigned int STATUS;         // Status register

		struct
		{
			const volatile unsigned int :1;
			const volatile unsigned int RXBF:1;     // Receive Buffer Full flag
			const volatile unsigned int TXBE:1;     // Transmit Buffer Empty flag
			const volatile unsigned int TC:1;       // Transfer Complete
			const volatile unsigned int FRERR:1;    // Framing Error
			const volatile unsigned int :27;
		};
	};

	union
	{
		volatile unsigned int CR1;                  // Control Register 1

		struct
		{
			volatile unsigned int PE:1;             // Peripheral Enable
			volatile unsigned int RXBFIE:1;         // Receive Buffer Full Interrupt Enable
			volatile unsigned int TXBEIE:1;         // Transmit Buffer Empty Interrupt Enable
			volatile unsigned int TCIE:1;           // Transfer Complete Interrupt Enable
			volatile unsigned int FRERRIE:1;        // Framing Error Interrupt Enable
			volatile unsigned int CPOL:1;           // Clock polarity
			volatile unsigned int CPHA:1;           // Clock phase
			volatile unsigned int MODE:1;           // SPI mode: 0 = master; 1 = slave
			volatile unsigned int :24;
		};
	};

	union
	{
		volatile unsigned int CR2;                  // Control Register 2

		struct
		{
			volatile unsigned int CLKDIV:16;        // Clock divider (value -1)
			volatile unsigned int :16;
		};
	};
} SPI_t;



#endif
