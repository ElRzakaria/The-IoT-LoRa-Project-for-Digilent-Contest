/**
 * author: Guillaume Patrigeon
 * update: 07-12-2018
 */

#ifndef __ARCH_I2C_H__
#define __ARCH_I2C_H__



typedef struct
{
	volatile unsigned int DATA;

	union
	{
		volatile unsigned int STATUS;           // Status register

		struct
		{
			volatile unsigned int RNW:1;        // Read not write
			volatile unsigned int RXBF:1;       // Receive Buffer Full Interrupt Flag
			volatile unsigned int TXBE:1;       // Transmit Buffer Empty Interrupt Flag
			volatile unsigned int TC:1;         // Transfer Complete Interrupt Flag
			volatile unsigned int FRERR:1;      // Framing Error Interrupt Flag
			volatile unsigned int BERR:1;       // Bus Error Interrupt Flag
			volatile unsigned int MATCH:1;      // Address Match Interrupt Flag
			volatile unsigned int NACKR:1;      // Not Acknowledge Received Interrupt Flag
			volatile unsigned int STARTR:1;     // Start condition Received Interrupt Flag
			volatile unsigned int STOPR:1;      // Stop condition Received Interrupt Flag
			volatile unsigned int BUSY:1;       // Bus is busy
			volatile unsigned int :21;
		};
	};

	union
	{
		volatile unsigned int CR1;              // Control Register 1

		struct
		{
			volatile unsigned int PE:1;         // Peripheral Enable
			volatile unsigned int RXBFIE:1;     // Receive Buffer Full Interrupt Enable
			volatile unsigned int TXBEIE:1;     // Transmit Buffer Empty Interrupt Enable
			volatile unsigned int TCIE:1;       // Transfer Complete Interrupt Enable
			volatile unsigned int FRERRIE:1;    // Framing Error Interrupt Enable
			volatile unsigned int BERRIE:1;     // Bus Error Interrupt Enable
			volatile unsigned int MATCHIE:1;    // Address Match Interrupt Enable
			volatile unsigned int NACKIE:1;     // Not Acknowledge received Interrupt Enable
			volatile unsigned int STARTIE:1;    // Start condition received Interrupt Enable
			volatile unsigned int STOPIE:1;     // Stop condition received Interrupt Enable
			volatile unsigned int MODE:1;       // 0 = master; 1 = slave
			volatile unsigned int NACK:1;       // Next NACK value to be sent
			volatile unsigned int SSTART:1;     // Send Start condition
			volatile unsigned int SSTOP:1;      // Send Stop condition
			volatile unsigned int :18;
		};
	};

	union
	{
		volatile unsigned int CR2;              // Control Register 2

		struct
		{
			volatile unsigned int CLKDIV:16;    // Clock divider (value -1)
			volatile unsigned int :16;
		};
	};

	volatile unsigned int ADDR;
} I2C_t;



#endif
