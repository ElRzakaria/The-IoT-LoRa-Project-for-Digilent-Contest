/**
 * author: Guillaume Patrigeon
 * update: 08-01-2019
 */

#ifndef __ARCH_NVIC_H__
#define __ARCH_NVIC_H__



typedef enum
{
	NVIC_NA_00,
	NVIC_NA_01,
	NVIC_NA_02,
	NVIC_NA_03,
	NVIC_TIMER1,        //NA_04
	NVIC_TIMER2,        //NA_05
	NVIC_TIMER3,        //NA_06
	NVIC_TIMER4,        //NA_07
	NVIC_UART1,         //NA_08
	NVIC_UART2,         //NA_09
	NVIC_UART3,         //NA_10
	NVIC_UART4,         //NA_11
	NVIC_SPI1,          //NA_12
	NVIC_SPI2,          //NA_13
	NVIC_SPI3,          //NA_14
	NVIC_SPI4,          //NA_15
	NVIC_I2C1,          //NA_16
	NVIC_I2C2,          //NA_17
	NVIC_I2C3,          //NA_18
	NVIC_I2C4,          //NA_19
	NVIC_NA_20,
	NVIC_NA_21,
	NVIC_NA_22,
	NVIC_NA_23,
	NVIC_NA_24,
	NVIC_NA_25,
	NVIC_NA_26,
	NVIC_NA_27,
	NVIC_NA_28,
	NVIC_NA_29,
	NVIC_NA_30,
	NVIC_NA_31,
	NVIC_NbLines
} NVIC_e;



#define TIMER1_IRQHandler       IRQ_04_Handler
#define TIMER2_IRQHandler       IRQ_05_Handler
#define TIMER3_IRQHandler       IRQ_06_Handler
#define TIMER4_IRQHandler       IRQ_07_Handler

#define UART1_IRQHandler        IRQ_08_Handler
#define UART2_IRQHandler        IRQ_09_Handler
#define UART3_IRQHandler        IRQ_10_Handler
#define UART4_IRQHandler        IRQ_11_Handler

#define SPI1_IRQHandler         IRQ_12_Handler
#define SPI2_IRQHandler         IRQ_13_Handler
#define SPI3_IRQHandler         IRQ_14_Handler
#define SPI4_IRQHandler         IRQ_15_Handler

#define I2C1_IRQHandler         IRQ_16_Handler
#define I2C2_IRQHandler         IRQ_17_Handler
#define I2C3_IRQHandler         IRQ_18_Handler
#define I2C4_IRQHandler         IRQ_19_Handler



#endif
