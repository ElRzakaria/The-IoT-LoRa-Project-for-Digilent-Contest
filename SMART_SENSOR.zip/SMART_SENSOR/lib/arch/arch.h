/**
 * author: Guillaume Patrigeon
 * update: 08-01-2019
 */

#ifndef __ARCH_H__
#define __ARCH_H__



// ======== REGISTERS =======
// AHB
#define GPIOA_BASE              0x40000000
#define GPIOB_BASE              0x40000400
#define GPIOC_BASE              0x40000800
#define GPIOD_BASE              0x40000C00

#define PPSIN_BASE              0x40010000
#define PPSOUT_BASE             0x40010400

#define RSTCLK_BASE             0x40011000
#define MONITOR_BASE            0x40011400

#define TIMER1_BASE             0x40018000
#define TIMER2_BASE             0x40018400
#define TIMER3_BASE             0x40018800
#define TIMER4_BASE             0x40018C00

#define UART1_BASE              0x40020000
#define UART2_BASE              0x40020400
#define UART3_BASE              0x40020800
#define UART4_BASE              0x40020C00

#define SPI1_BASE               0x40021000
#define SPI2_BASE               0x40021400
#define SPI3_BASE               0x40021800
#define SPI4_BASE               0x40021C00

#define I2C1_BASE               0x40022000
#define I2C2_BASE               0x40022400
#define I2C3_BASE               0x40022800
#define I2C4_BASE               0x40022C00


// ======== DEFINITIONS =======
#include "arch_gpio.h"
#include "arch_i2c.h"
#include "arch_monitor.h"
#include "arch_nvic.h"
#include "arch_pps.h"
#include "arch_rstclk.h"
#include "arch_spi.h"
#include "arch_timer.h"
#include "arch_uart.h"


// ======== PERIPHERALS =======
// GPIO
#define GPIOA                   (*(GPIO_t*)GPIOA_BASE)
#define GPIOB                   (*(GPIO_t*)GPIOB_BASE)
#define GPIOC                   (*(GPIO_t*)GPIOC_BASE)
#define GPIOD                   (*(GPIO_t*)GPIOD_BASE)

// PPS
#define PPSIN                   (*(PPSIN_t*)PPSIN_BASE)
#define PPSOUT                  (*(PPSOUT_t*)PPSOUT_BASE)

// Reset and clock control
#define RSTCLK                  (*(RSTCLK_t*)RSTCLK_BASE)

// Activity monitor
#define MONITOR                 (*(MONITOR_t*)MONITOR_BASE)

// TIMER
#define TIMER1                  (*(TIMER_t*)TIMER1_BASE)
#define TIMER2                  (*(TIMER_t*)TIMER2_BASE)
#define TIMER3                  (*(TIMER_t*)TIMER3_BASE)
#define TIMER4                  (*(TIMER_t*)TIMER4_BASE)

// UART
#define UART1                   (*(UART_t*)UART1_BASE)
#define UART2                   (*(UART_t*)UART2_BASE)
#define UART3                   (*(UART_t*)UART3_BASE)
#define UART4                   (*(UART_t*)UART4_BASE)

// SPI
#define SPI1                    (*(SPI_t*)SPI1_BASE)
#define SPI2                    (*(SPI_t*)SPI2_BASE)
#define SPI3                    (*(SPI_t*)SPI3_BASE)
#define SPI4                    (*(SPI_t*)SPI4_BASE)

// I2C
#define I2C1                    (*(I2C_t*)I2C1_BASE)
#define I2C2                    (*(I2C_t*)I2C2_BASE)
#define I2C3                    (*(I2C_t*)I2C3_BASE)
#define I2C4                    (*(I2C_t*)I2C4_BASE)



#endif
