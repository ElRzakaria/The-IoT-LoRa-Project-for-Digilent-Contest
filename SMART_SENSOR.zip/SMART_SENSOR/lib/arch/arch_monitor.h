/**
 * author: Guillaume Patrigeon
 * update: 19-06-2018
 */

#ifndef __ARCH_MONITOR_H__
#define __ARCH_MONITOR_H__



#define MONITOR_CR_START        0x00000001
#define MONITOR_CR_STOP         0x00000002
#define MONITOR_CR_RSTALL       0x0001FF00

#define MONITOR_CR_RSTCYCC      0x00000100
#define MONITOR_CR_RSTINSTC     0x00000200
#define MONITOR_CR_RSTFETCHC    0x00000400
#define MONITOR_CR_RSTRAMRBC    0x00000800
#define MONITOR_CR_RSTRAMRHC    0x00001000
#define MONITOR_CR_RSTRAMRWC    0x00002000
#define MONITOR_CR_RSTRAMWBC    0x00004000
#define MONITOR_CR_RSTRAMWHC    0x00008000
#define MONITOR_CR_RSTRAMWWC    0x00010000



typedef struct
{
	union
	{
		volatile unsigned int CR;               // Control register

		struct
		{
			volatile unsigned int CE:1;         // Counters Enabled
			volatile unsigned int :31;
		};
	};

	volatile unsigned int :32;

	volatile unsigned int CYCCR;                // Cycle Counter Register
	volatile unsigned int INSTCR;               // Instruction Counter Register
	volatile unsigned int FETCHCR;              // Fetch Counter Register
	volatile unsigned int RAMRBCR;              // RAM 8-bit Read Counter Register
	volatile unsigned int RAMRHCR;              // RAM 16-bit Read Counter Register
	volatile unsigned int RAMRWCR;              // RAM 32-bit Read Counter Register
	volatile unsigned int RAMWBCR;              // RAM 8-bit Write Counter Register
	volatile unsigned int RAMWHCR;              // RAM 16-bit Write Counter Register
	volatile unsigned int RAMWWCR;              // RAM 32-bit Write Counter Register
} MONITOR_t;



#endif
