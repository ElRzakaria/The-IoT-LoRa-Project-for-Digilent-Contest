/**
 * author: Guillaume Patrigeon
 * update: 08-01-2019
 */

#ifndef __ARCH_PPS_H__
#define __ARCH_PPS_H__



typedef enum
{
	PPSIN_UART1_RXD,
	PPSIN_UART2_RXD,
	PPSIN_UART3_RXD,
	PPSIN_UART4_RXD,

	PPSIN_SPI1_SSn,
	PPSIN_SPI1_SCK,
	PPSIN_SPI1_SDI,
	PPSIN_SPI2_SSn,
	PPSIN_SPI2_SCK,
	PPSIN_SPI2_SDI,
	PPSIN_SPI3_SSn,
	PPSIN_SPI3_SCK,
	PPSIN_SPI3_SDI,
	PPSIN_SPI4_SSn,
	PPSIN_SPI4_SCK,
	PPSIN_SPI4_SDI,

	PPSIN_I2C1_SCL,
	PPSIN_I2C1_SDA,
	PPSIN_I2C2_SCL,
	PPSIN_I2C2_SDA,
	PPSIN_I2C3_SCL,
	PPSIN_I2C3_SDA,
	PPSIN_I2C4_SCL,
	PPSIN_I2C4_SDA,

	_PPSIN_NbLines
} PPSIN_e;

typedef enum
{
	PPSOUT_GPIO,

	PPSOUT_UART1_TXD,
	PPSOUT_UART2_TXD,
	PPSOUT_UART3_TXD,
	PPSOUT_UART4_TXD,

	PPSOUT_SPI1_SCK,
	PPSOUT_SPI1_SDO,
	PPSOUT_SPI2_SCK,
	PPSOUT_SPI2_SDO,
	PPSOUT_SPI3_SCK,
	PPSOUT_SPI3_SDO,
	PPSOUT_SPI4_SCK,
	PPSOUT_SPI4_SDO,

	PPSOUT_I2C1_SCL,
	PPSOUT_I2C1_SDA,
	PPSOUT_I2C2_SCL,
	PPSOUT_I2C2_SDA,
	PPSOUT_I2C3_SCL,
	PPSOUT_I2C3_SDA,
	PPSOUT_I2C4_SCL,
	PPSOUT_I2C4_SDA,

	_PPSOUT_NbLines
} PPSOUT_e;

typedef enum
{
	PPS_PORTA,
	PPS_PORTB,
	PPS_PORTC,
	PPS_PORTD,
	_PPS_NbPorts
} PORT_e;



typedef union
{
	volatile unsigned int PPS;                  // Pin peripheral selection

	struct
	{
		volatile unsigned int PIN:4;            // UART Enable
		volatile unsigned int PORT:2;           // Port selection
		volatile unsigned int :26;
	};
} PPSIN_REG_t;

typedef PPSIN_REG_t PPSIN_t[_PPSIN_NbLines];



typedef struct
{
	volatile unsigned int PORTA[16];
	volatile unsigned int PORTB[16];
	volatile unsigned int PORTC[16];
	volatile unsigned int PORTD[16];
} PPSOUT_t;



#endif
