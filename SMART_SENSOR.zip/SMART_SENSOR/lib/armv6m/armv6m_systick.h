/**
 * author: Guillaume Patrigeon
 * update: 28-03-2017
 */

#ifndef __ARMV6M_SYSTICK_H__
#define __ARMV6M_SYSTICK_H__

#include "armv6m.h"

#define SYSTICK                 (*(SYSTICK_t*)ARMV6M_SYSTICK_BASE) // System timer



typedef enum
{
	SYSTICK_CLKSOURCE_EXTERNAL,
	SYSTICK_CLKSOURCE_INTERNAL
} SYSTICK_CLKSOURCE_e;



typedef struct
{
	union
	{
		volatile unsigned int CSR;              // SysTick Control and Status Register

		struct
		{
			volatile unsigned int ENABLE:1;     // SysTick enable
			volatile unsigned int TICKINT:1;    // SysTick count-to-zero interrupt enable
			volatile unsigned int CLKSOURCE:1;  // SysTick clock source (see SYSTICK_CLKSOURCE_xxx)
			volatile unsigned int :13;
			volatile unsigned int COUNTFLAG:1;  // Count-to-zero flag (cleared by register read)
			volatile unsigned int :15;
		};
	};

	volatile unsigned int RELOAD;               // SysTick Reload Value
	volatile unsigned int CURRENT;              // SysTick Current Counter Value

	union
	{
		const volatile unsigned int CALIB;              // SysTick Calibration Register

		struct
		{
			const volatile unsigned int TENMS:24;       // Holds the reload value for a 100 Hz clock (unknown if 0)
			const volatile unsigned int :6;
			const volatile unsigned int SKEW:1;         // Inexact calibration value flag
			const volatile unsigned int NOREF:1;        // External reference not implemented flag
		};
	};
} SYSTICK_t;



#endif
