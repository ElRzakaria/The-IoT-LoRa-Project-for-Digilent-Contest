/**
 * author: Guillaume Patrigeon
 * update: 28-03-2017
 */

#ifndef __ARMV6M_SCB_H__
#define __ARMV6M_SCB_H__

#include "armv6m.h"

#define SCB                     (*(SCB_t*)ARMV6M_SCB_BASE)      // System Control Block



typedef struct
{
	union
	{
		const volatile unsigned int CPUID;                      // CPUID Base Register

		struct
		{
			const volatile unsigned int REVISION:4;             // Revision number
			const volatile unsigned int PARTNO:12;              // Part number
			const volatile unsigned int ARCHITECTURE:4;         // ARMv6-M (Ch)
			const volatile unsigned int VARIANT:4;              // Variant number
			const volatile unsigned int IMPLEMENTER:8;          // Implementer (41h)
		};
	};

	union
	{
		volatile unsigned int ICSR;             // Interrupt Control and State Register

		struct
		{
			volatile unsigned int VECTACTIVE:9; // Current executing exception number. If 0 processor is in Thread mode
			volatile unsigned int :3;
			volatile unsigned int VECTPENDING:9;// Exception number of the highest priority pending and enabled interrupt
			volatile unsigned int :1;
			volatile unsigned int ISRPENDING:1; // Indicate whether there is a external interrupt (from NVIC)
			volatile unsigned int ISRPREEMPT:1; // Indicates whether a pending exception will be serviced on exit from debug halt state
			volatile unsigned int :1;
			volatile unsigned int PENDSTCLR:1;  // Removes the pending status of the SysTick exception
			volatile unsigned int PENDSTSET:1;  // Set (WR) or test (RD) the SysTick exception
			volatile unsigned int PENDSVCLR:1;  // Removes the pending status of the PendSV exception
			volatile unsigned int PENDSVSET:1;  // Set (WR) or test (RD) the PendSV exception
			volatile unsigned int :2;
			volatile unsigned int NMIPENDSET:1; // Set (WR) or test (RD) the NMI exception
		};
	};

	union
	{
		volatile unsigned int VTOR;             // Vector Table Offset Register

		struct
		{
			volatile unsigned int :7;
			volatile unsigned int TBLOFF:25;    // Vector table address offset
		};
	};

	union
	{
		volatile unsigned int AIRCR;            // Application Interrupt and Reset Control Register

		struct
		{
			volatile unsigned int :1;
			volatile unsigned int VECTCLRACTIVE:1;      // Clear all active state information for all exceptions
			volatile unsigned int SYSRESETREQ:1;        // System Reset Request
			volatile unsigned int :12;
			volatile unsigned int ENDIANNESS:1;         // Indicates the memory system endianness
			volatile unsigned int VECTKEY:16;           // On read, give the reversed vector key
		};
	};

	union
	{
		volatile unsigned int SCR;              // System Control Register

		struct
		{
			volatile unsigned int :1;
			volatile unsigned int SLEEPONEXIT:1;// Return in sleep mode after an ISR
			volatile unsigned int SLEEPDEEP:1;  // Selected sleep state is deep sleep
			volatile unsigned int :1;
			volatile unsigned int SEVONPEND:1;  // Interrupt transition is a wake-up event
			volatile unsigned int :27;
		};
	};

	union
	{
		volatile unsigned int CCR;              // Configuration and Control Register

		struct
		{
			volatile unsigned int :3;
			volatile unsigned int UNALIGN_TRP:1;// Enable trapping of unaligned word and halfword accesses
			volatile unsigned int :5;
			volatile unsigned int STKALIGN:1;   // Byte alignment at exception entry: 0 = 4-byte; 1 = 8-byte
			volatile unsigned int :22;
		};
	};

	volatile unsigned int :32;

	union
	{
		volatile unsigned int SHPR2;            // System Handler Priority Register 2

		struct
		{
			volatile unsigned int :30;
			volatile unsigned int PRI_SVCALL:2; // Priority of system handler 11, SVCall
		};
	};

	union
	{
		volatile unsigned int SHPR3;            // System Handler Priority Register 3

		struct
		{
			volatile unsigned int :22;
			volatile unsigned int PRI_PENDSV:2; // Priority of system handler 14, PendSV
			volatile unsigned int :6;
			volatile unsigned int PRI_SYSTICK:2;// Priority of system handler 15, SysTick
		};
	};

	union
	{
		volatile unsigned int SHCSR;            // System Handler Control and State Register

		struct
		{
			volatile unsigned int :15;
			volatile unsigned int SVCALLPENDED:1;       // SVCall pending
			volatile unsigned int :16;
		};
	};

	volatile unsigned int :32;
	volatile unsigned int :32;

	union
	{
		volatile unsigned int DFSR;             // Debug Fault Status Register

		struct
		{
			volatile unsigned int HALTED:1;     // Halt request debug event flag
			volatile unsigned int BKPT:1;       // Breakpoint event flag
			volatile unsigned int DWTTRAP:1;    // DWT generated debug event flag
			volatile unsigned int VCATCH:1;     // Vector cache trigger flag
			volatile unsigned int EXTERNAL:1;   // External debug request debug event flag
			volatile unsigned int :27;
		};
	};
} SCB_t;



#endif
