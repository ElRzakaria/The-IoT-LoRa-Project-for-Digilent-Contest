/**
 * author: Guillaume Patrigeon
 * update: 05-10-2018
 */

#ifndef __ARMV6M_H__
#define __ARMV6M_H__

#define ARMV6M_SYSTICK_BASE     0xE000E010
#define ARMV6M_NVIC_BASE        0xE000E100
#define ARMV6M_SCB_BASE         0xE000ED00

#include "armv6m_systick.h"
#include "armv6m_nvic.h"
#include "armv6m_scb.h"



#define _SOFTWARE_RESET()       SCB.AIRCR = 0x05FA0004
#define _INTERRUPTS_ENABLE()    asm("CPSIE I")
#define _INTERRUPTS_DISABLE()   asm("CPSID I")
#define _NOP()                  asm("NOP")
#define _WFE()                  asm("WFE")
#define _WFI()                  asm("WFI")



#endif
