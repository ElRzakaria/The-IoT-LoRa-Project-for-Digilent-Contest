/**
 * author: Guillaume Patrigeon
 * update: 05-10-2018
 */

#ifndef __ARMV6M_NVIC_H__
#define __ARMV6M_NVIC_H__

#include "armv6m.h"

#define _NVIC_WR_REG(reg, line) (reg)[(line)/32] = 1 << ((line) & 0x1F)
#define _NVIC_RD_REG(reg, line) (((reg)[(line)/32] >> ((line) & 0x1F)) & 1)

#define NVIC_SET_ENABLE(line)   _NVIC_WR_REG((volatile unsigned int*)(ARMV6M_NVIC_BASE), line)
#define NVIC_CLR_ENABLE(line)   _NVIC_WR_REG((volatile unsigned int*)(ARMV6M_NVIC_BASE+0x0080), line)

#define NVIC_SET_PENDING(line)  _NVIC_WR_REG((volatile unsigned int*)(ARMV6M_NVIC_BASE+0x0100), line)
#define NVIC_CLR_PENDING(line)  _NVIC_WR_REG((volatile unsigned int*)(ARMV6M_NVIC_BASE+0x0180), line)

#define NVIC_PRIORITY(line)     ((volatile unsigned char*)(ARMV7M_NVIC_BASE+0x0300))[line]



#endif
