/*
 *
 *    ADAC Research Group - LIRMM - University of Montpellier / CNRS
 *    contact: adac@lirmm.fr
 *
 *    This file is part of SecretBlaze.
 *
 *    SecretBlaze is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU Lesser General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    SecretBlaze is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    Lesser GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public License
 *    along with SecretBlaze.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * \file main.c
 * \brief Agriscope's Application (Sigfox STC module) testbench
 * \author LIRMM - Sophiane Senni
 * \version 1.0
 * \date 01/08/2018
 */

// #include "sb_types.h"
// #include "sb_uart.h"
// #include "sb_nvcontrol.h"
// #include "sb_timer.h"
// #include "sb_intc.h"
// #include "sb_msr.h"

#include <TMP2.h>

// Agriscope's Application headers
#include "agspMain.h"
#include "agspCounter.h"
#include "agspSigfox.h"

/* Global variables */

// sb_uint8_t cycle=0;

// STC values
agspMeasure_t agspMeasure;
// Sigfox Module Type
agspConfiguration_t agspConfiguration;

// Count of agsp_measureSampleCallBack function calls
sb_uint32_t agspCallBackCount ;

// String message to send via Sigfox
sb_uint8_t sigfoxMessage[AGSP_SIGFOX_MESSAGE_LENGTH];

// Sigfox status
sb_bool_t sigfoxStatus;


/*****************************************************************************
 * AGSP_mainInit()
 *
 * Measurement & Configuration variables initialization
 *
 ******************************************************************************/
void initAGSP()
{
	// Variables initialization
	AGSP_mainInit();

	// WatchDog initialization
	AGSP_initWatchDog();

	// Counter initialization
	AGSP_counterInit();

	// Force sampling at first boot
	//AGSP_measureSampleCallBack();
}


void AGSP_mainInit()
{
  agspCallBackCount = 0;

  agspMeasure.counter = 0;

  agspConfiguration.agspSigfoxModType = AGSP_SIGFOX_STC_MOD_TYPE;
  agspConfiguration.agspMeasureStepMilliSeconds = AGSP_SAMPLING_CALLBACK;
}

/*****************************************************************************
 * AGSP_initWatchDog()
 *
 * WatchDog initialization
 *
 ******************************************************************************/

void AGSP_initWatchDog()
{
  // Initialize a 128s watchdog
  timer_2_init(WATCHDOG_VALUE);
  timer_2_enable();
}

/*****************************************************************************
 * void AGSP_measureSampleCallBack()
 *
 * Measure, read values and send via sigfox.
 *
 ******************************************************************************/

void AGSP_measureSampleCallBack()
{

  // WatchDog reset
  timer_2_reset();
  timer_2_enable();

  /* RESET timer_1 */
  timer_1_reset();
  timer_1_enable();

  agspCallBackCount++;

  /* read counter */
  agspMeasure.counter = AGSP_counterGetValue();

  /* read temperature */
  agspMeasure.temp = GetTemperature();

  // send by sigfox
  //sigfoxStatus=sb_false;
  sigfoxStatus=agspSigfoxSend(agspMeasure, agspConfiguration.agspSigfoxModType);

  // cycle++;
}
