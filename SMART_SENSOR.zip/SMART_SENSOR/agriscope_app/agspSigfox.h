#ifndef _AGSP_SIGFOX_H
#define _AGSP_SIGFOX_H

/**
 * \file agspSigfox.h
 * \brief Agriscope's Application: Sigfox functions
 * \author LIRMM - Sophiane Senni
 * \version 1.0
 * \date 01/08/2018 
 */
 
#include "globals.h"

sb_bool_t agspSigfoxSend(agspMeasure_t meas, sb_uint8_t agspType);

#endif
