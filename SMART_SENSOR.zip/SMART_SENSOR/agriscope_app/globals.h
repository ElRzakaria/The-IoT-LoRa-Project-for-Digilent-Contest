#ifndef GLOBALS_H_
#define GLOBALS_H_

/**
 * \file globals.h
 * \brief Agriscope's Application: Global variables
 * \author LIRMM - Sophiane Senni
 * \version 1.0
 * \date 01/08/2018
 */

// #include "sb_types.h"
// #include "sb_io.h"
// #include "sb_def.h"
#include <system.h>
#define sb_bool_t       bool
#define sb_uint8_t      unsigned char
#define sb_uint16_t     unsigned short
#define sb_uint32_t     unsigned int
#define sb_false        false
#define sb_true         true


/**********************************************************************
 *
 * General definition
 *
 *********************************************************************/

#define input(adr)			READ_REG32(adr)
#define output(adr,data)	WRITE_REG32(adr,data)

 /**********************************************************************
 *
 * AGSP module types definition
 *
 *********************************************************************/

#define AGSP_SIGFOX_NONE_MOD_TYPE 	      	0x00
#define AGSP_SIGFOX_STC_MOD_TYPE  			0x01
#define AGSP_SIGFOX_MESSAGE_LENGTH          5

 /**********************************************************************
 *
 * Data structures definition
 *
 * agspMeasure et agspConfiguration
 *
 *********************************************************************/

typedef struct
{
	sb_uint16_t counter;
	sb_uint16_t temp;
	// add other data here
} agspMeasure_t;


typedef struct
{
	sb_uint8_t  agspSigfoxModType ;
	sb_uint32_t agspMeasureStepMilliSeconds;
} agspConfiguration_t;

 /**********************************************************************
 *
 * Global variables declaration
 *
 * agspMeasure et agspConfiguration
 *
 *********************************************************************/

// STC values
extern agspMeasure_t agspMeasure;
// Sigfox Module Type
extern agspConfiguration_t agspConfiguration;

// Count of agsp_measureSampleCallBack function calls
extern sb_uint32_t agspCallBackCount ;

// String message to send via Sigfox
extern sb_uint8_t sigfoxMessage[AGSP_SIGFOX_MESSAGE_LENGTH];

// Sigfox status
extern sb_bool_t sigfoxStatus;

#endif /* GLOBALS_H_ */
