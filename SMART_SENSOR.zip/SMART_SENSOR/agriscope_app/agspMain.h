#ifndef AGSP_MAIN_H_
#define AGSP_MAIN_H_

/**
 * \file main.h
 * \brief Agriscope's Application: Main functions
 * \author LIRMM - Sophiane Senni
 * \version 1.0
 * \date 01/08/2018
 */

#include "globals.h"

/**********************************************************************
 *
 * Parameters definition
 *
 *********************************************************************/

/* On/Off cycle count */
#define CYCLE_COUNT 3

/* Sampling period */
#define AGSP_SAMPLING_CALLBACK 0x493E0 // 15ms @20MHz

/* WatchDog period */
#define WATCHDOG_VALUE 0x98968000 // 128s @20MHz

/***************************************************************************//**
 *
 * Main functions
 *
 ******************************************************************************/
void initAGSP();
void AGSP_mainInit();
void AGSP_initWatchDog();
void AGSP_measureSampleCallBack();
// void AGSP_binkDiodeRepeat(int repeat);

#endif
