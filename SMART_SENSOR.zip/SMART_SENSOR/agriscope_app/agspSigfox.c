/**
 * \file agspSigfox.c
 * \brief Agriscope's Application: Sigfox functions
 * \author LIRMM - Sophiane Senni
 * \version 1.0
 * \date 01/08/2018
 */

#include "globals.h"
#include "agspSigfox.h"

/*
 * agspType = 0x01
 * AgpsSigfoxFrame =
 * [ Type ] [ Counter ] [ Temp ] [ Hygro ] [ Analog ] [ PreviousAlim]
 *
 * where
 * [ Type         ] = <type>                                : 8 bits
 *
 * Type = 0x01 : =>
 *
 * [ Counter      ] = < counter_h > < counter_l >           : 16 bits
 * [ Temp         ] = < temp_h > < counter_l >              : 16 bits
 * [ Hygro        ] = < hygro_h > < counter_l >             : 16 bits
 * [ Analog       ] = < analog_h > < counter_l >            : 16 bits
 * [ PreviousAlim ] = < previousAlim_h > < previousAlim_l > : 16 bits
 */
sb_bool_t agspSigfoxSend(agspMeasure_t meas, sb_uint8_t agspType)
{
	sigfoxMessage[0] = agspType & 0xFF;
	sigfoxMessage[1] = 0xFF & meas.counter >> 8;
	sigfoxMessage[2] = 0xFF & meas.counter;
	sigfoxMessage[1] = 0xFF & meas.temp >> 8;
	sigfoxMessage[2] = 0xFF & meas.temp;

	/*bool TD_SIGFOX_SendV1  ( uint8_t  mode,
			  bool  value,
			  uint8_t *  message,
			  uint8_t  size,
			  uint8_t  retry,
			  bool  ack,
			  bool  reserved
			 )
    */
	// return TD_SIGFOX_SendV1  ( MODE_FRAME,
				  // false,
				  // sigfoxMessage,
				  // size,
				  // 2, // 2 retry
				  // false,
				  // false
				 // );
/*
	printf("Send");
	for (int i=0; i<AGSP_SIGFOX_MESSAGE_LENGTH; i++)
		printf(" %02X", sigfoxMessage[i]);
	printc('\n');
*/
	// SendPackageLoRa(sigfoxMessage, 3);

	return 1; // Source code of TD_SIGFOX_Send() not available
}
