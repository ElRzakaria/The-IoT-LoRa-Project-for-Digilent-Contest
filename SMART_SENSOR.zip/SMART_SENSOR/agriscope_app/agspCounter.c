/**
 * \file agspCounter.c
 * \brief Agriscope's Application: Counter functions
 * \author LIRMM - Sophiane Senni
 * \version 1.0
 * \date 01/08/2018
 */

#include "agspCounter.h"
// #include "sb_intc.h"

sb_uint16_t counter =0;
sb_uint16_t callBackCounter =0;
sb_bool_t counterEvent = sb_false;

/***************************************************************************//**
 * AGSP_counterCallback()
 *
 * Callback function further to an interrupt event
 *
 ******************************************************************************/
void AGSP_counterCallback()
{
	callBackCounter++;
	counterEvent = sb_true;
}

/***************************************************************************//**
 * AGSP_counterGetValue()
 *
 *
 * Returns current value of the counter
 ******************************************************************************/
sb_uint16_t AGSP_counterGetValue()
{
	return counter;
}

/***************************************************************************//**
 *  AGSP_counterLoop ()
 *
 * Called at each wakeup
 * Update of the counter's value
 ******************************************************************************/

void AGSP_counterLoop()
{
	if (counterEvent == sb_true)
	{
		counter++;
		counterEvent = sb_false;
	}
}


/**********************	*****************************************************//**
 *  AGSP_counterInit ()
 *
 * Initialization and configuration of the counter
 ******************************************************************************/

void AGSP_counterInit()
{
	counterEvent = sb_false;
	counter=0;
	// No need to configure GPIO as input or output for SB cpu (done by hardware)

	/* attach handler for gpio input 0 */
    // intc_attach_handler(INTC_ID_8,(sb_interrupt_handler)(&AGSP_counterCallback),0);
	/* Configure gpio input 0 interrupt on rising edge event */
	// output(GPIO_INT_CONFIG_REG,0x00);
	/* Enable gpio input 0 interrupt */
	// output(GPIO_INT_ENABLE_REG,GPIO_IN0_BIT);
}
