#ifndef _AGSP_COUNTER_H
#define _AGSP_COUNTER_H

/**
 * \file agspCounter.h
 * \brief Agriscope's Application: Counter functions
 * \author LIRMM - Sophiane Senni
 * \version 1.0
 * \date 01/08/2018 
 */
 
#include "globals.h"


 /*   _______________                  _____________________
 *                  \               /
 *   COUNTER    IN   |   --------- |  USR0 [ pin 10 ]	pin du Module TD1208
 *              GND  |   --------- |  GND  [ pin 6  ]
 *   ______________ /              \______________________
 *
 */

/*
 * voir https://www.silabs.com/Support%20Documents/TechnicalDocs/EFM32G210.pdf
 * #define	USR0_PORT               gpioPortB
 * #define	USR0_BIT                13 13 entree du port B, c'est donc impair
 * #define	USR0_MASK               (1 << USR0_BIT)
 * #define	USR0_PIN                12 pin12 du composant (voir pinout)
 */

// #define COUNTER_PORT 	USR0_PORT
// #define COUNTER_BIT  	USR0_BIT
// #define COUNTER_MASK 	USR0_MASK


/**********************************************************************
 * void AGSP_initCounter ()
 *
 * Counter initialization and configuration
 * 
 *
 **********************************************************************/
void AGSP_counterInit();

/**********************************************************************
 * static void AGSP_counterLoop
 *
 *
 * Appel par la loop principale pour recuperer les valeurs de counter
 *
 **********************************************************************/



void AGSP_counterLoop();
/**********************************************************************
 * static void AGSP_counterCallback()
 *
 *
 * Counter interrupt callback function. Increment a value.
 *
 **********************************************************************/
void AGSP_counterCallback();



/**********************************************************************
 * sb_uint16_t AGSP_getCounterValue();
 *
 *
 * Returns current counter value
 *
 **********************************************************************/
sb_uint16_t AGSP_counterGetValue();


#endif
