/**
 * OLED library
 * author: Paul Leloup
 * update: 08-01-2019
 */

//Constantes


//PMODOLEDBASDROITE
/*
#define SS2 GPIOC.ODRbits.P13
#define DATACMD GPIOD.ODRbits.P0
#define RESET GPIOD.ODRbits.P1
#define VBATC GPIOD.ODRbits.P2
#define VDDC GPIOD.ODRbits.P3

//LORA1

//Programme test
void testOLED(unsigned char reg);

//Initialise le module OLED
void initOLED();

//Reset le module OLED
void resetOLED();
*/
