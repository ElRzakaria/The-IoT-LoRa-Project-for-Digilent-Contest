/**
 * TMP2 library
 * author: Paul Leloup
 * update: 11-01-2018
 */

short GetTemperature(void);
