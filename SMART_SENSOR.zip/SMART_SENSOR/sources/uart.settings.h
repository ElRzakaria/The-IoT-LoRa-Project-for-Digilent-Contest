#ifndef __UART_SETTINGS_H__
#define __UART_SETTINGS_H__


//*
#define _USE_UART1
#define UART1_TXBUFFERSIZE      1024
#define UART1_RXBUFFERSIZE      32
// */


#define _USE_UART2
#define UART2_TXBUFFERSIZE      1024
#define UART2_RXBUFFERSIZE      1024
// */


#define _USE_UART3
#define UART3_TXBUFFERSIZE      4096
#define UART3_RXBUFFERSIZE      4096
//

/*
#define _USE_UART4
#define UART4_TXBUFFERSIZE      256
#define UART4_RXBUFFERSIZE      256
// */

/*
#define _USE_UART5
#define UART5_TXBUFFERSIZE      256
#define UART5_RXBUFFERSIZE      256
// */

/*
#define _USE_UART6
#define UART6_TXBUFFERSIZE      256
#define UART6_RXBUFFERSIZE      256
// */

/*
#define _USE_UART7
#define UART7_TXBUFFERSIZE      256
#define UART7_RXBUFFERSIZE      256
// */


#endif
