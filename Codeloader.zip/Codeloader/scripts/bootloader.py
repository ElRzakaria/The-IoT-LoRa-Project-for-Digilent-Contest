#!/usr/bin/env python3
# author: Guillaume Patrigeon
# update: 17-01-2018

import os, time, threading

import tkinter as tki
from tkinter import ttk
from tkinter import messagebox, filedialog
from . import tkinterutils as tku

from . import hexdecoder



# ----------------------------------------------------------------
class BootloaderFrame(ttk.LabelFrame):
	def __init__(self, parent, qInput, qOutput, *args, **kw):
		ttk.LabelFrame.__init__(self, parent, *args, **kw)
		self.parent = parent
		self.qInput = qInput
		self.qOutput = qOutput

		# --------------------------------
		ttk.Style().configure("Error.Horizontal.TProgressbar", foreground="#FFF", background="#F00")

		# --------------------------------
		# Variables
		self.filenameVar = tki.StringVar()
		self.progressVar = tki.IntVar()

		# --------------------------------
		# Top frame
		self.frame = ttk.Frame(self)

		# Filename
		self.en_Filename = ttk.Entry(self.frame, textvariable=self.filenameVar)
		self.bt_Choose = ttk.Button(self.frame, text="...", command=self.selectFile)

		# Start
		self.bt_Start = ttk.Button(self.frame, text="Start", command=self.start)

		# Progress bar
		self.pb_Bar = tku.ProgressBar(self, variable=self.progressVar, color="grey")

		# --------------------------------
		# Create frame
		ttk.Label(self.frame, text="HEX file:").pack(side="left", padx=5, pady=5)
		self.en_Filename.pack(side="left", fill="x", expand=True, padx=5, pady=5)
		self.bt_Choose.pack(side="left", padx=5, pady=5)
		self.bt_Start.pack(side="left", padx=5, pady=5)

		self.frame.pack(fill="x")
		self.pb_Bar.pack(fill="both", padx=5, pady=5)

		# --------------------------------
		# Synchronization flags for internal thread
		self.flagRun = threading.Event()
		self.flagEvent = threading.Event()

		# Synchronization Lock
		self.lockSubprocess = threading.Lock()

		# Start thread
		self.flagRun.set()
		self.thread = threading.Thread(target=self.task, name="Bootloader task")
		self.thread.start()


	# --------------------------------
	def destroy(self):
		# Inform that task have to finish
		self.flagRun.clear()
		# Set event flag to ensure that the child thread will end
		self.flagEvent.set()
		# Join the child thread
		self.thread.join()
		# Normal destoy of this frame
		ttk.Frame.destroy(self)


	# --------------------------------
	def selectFile(self):
		self.filenameVar.set(filedialog.askopenfilename(title="Select file", filetypes=[("HEX files", "*.hex"), ("All files", "*.*")]))


	# --------------------------------
	def start(self):
		# Retrieve filename
		filename = self.filenameVar.get()

		# Check filename
		if filename == "" or not os.path.exists(filename):
			messagebox.showwarning("No file", "Please select a file!")
			return

		# Try to open file
		try:
			file = open(filename, "r")
		except:
			messagebox.showerror("Error", "Unable to open " + filename)
			return

		# Lock acces to subprocess object
		self.lockSubprocess.acquire()
		# Retrieve records
		try:
			self.records = hexdecoder.RecordBloc(file)
			self.records.reformat(32)
		except:
			# Release acces to subprocess object
			self.lockSubprocess.release()
			# Close file
			messagebox.showerror("Error", "Invalid file!\n" + filename)
			file.close()
			return

		# Release acces to subprocess object
		self.lockSubprocess.release()

		# Close file
		file.close()
		# Inform child task
		self.flagEvent.set()


	# --------------------------------
	def task(self):
		# Run while run flag is set
		while self.flagRun.is_set():
			# Wait an event occur (open or exit)
			self.flagEvent.wait()
			self.flagEvent.clear()

			# Check end of process
			if not self.flagRun.is_set():
				break

			# Lock acces to subprocess object
			self.lockSubprocess.acquire()

			total = len(self.records.records)

			self.progressVar.set(0)
			self.pb_Bar.setColor("blue")
			self.pb_Bar.setMax(total)

			# Flush input queue
			try:
				while not self.qInput.empty():
					dummy = self.qInput.get_nowait()
					time.sleep(0.02)
			except:
				pass


			data = None
			timeout = .0
			retry = 0
			i = j = k = 0
			while j < total:
				# Leave some time
				time.sleep(0.002)

				# Check end of process
				if not self.flagRun.is_set():
					break

				# Check receive queue
				if not self.qInput.empty():
					try:
						rep = self.qInput.get_nowait()
					except:
						continue

					# Check if data is valid
					if data and len(rep) == 2:
						# Abort if no ACK received
						if rep[0] != data[0] or rep[1] != 6:
							self.pb_Bar.setColor("red")
							break

						data = None

						# Update progress bar
						j += 1
						self.progressVar.set(j)

						# End of downloading
						if j == total:
							self.pb_Bar.setColor("green")
							break

				# If no response is comming
				if data and time.time() > timeout:
					timeout = time.time() + .1

					if not retry:
						self.pb_Bar.setColor("red")
						break

					retry -= 1
					self.qOutput.put(data)

				# If message queue is ready
				elif not data:
					record = self.records.records[i]

					# Build message
					data = bytes([0, record.type])
					data += record.offset.to_bytes(2, "little")

					if record.type == hexdecoder.RecordType.DATAREC.value or record.type == hexdecoder.RecordType.END.value:
						data += bytes(record.data)
					elif record.type == hexdecoder.RecordType.LINADDR.value or record.type == hexdecoder.RecordType.SEGADDR.value:
						data += bytes([record.data[1], record.data[0]])

					# Send message
					self.qOutput.put(data)
					timeout = time.time() + .1

					if i:
						retry = 5
					else:
						retry = 50

					i += 1

			# Release acces to subprocess object
			self.lockSubprocess.release()



# ----------------------------------------------------------------
if __name__ == "__main__":
	root = tki.Tk()
	a = BootloaderFrame(root, None, None)
	a.pack(fill="both", expand=True)

	root.resizable(height=False)
	root.title("BootloaderFrame")
	try:
		root.iconbitmap("icon.ico")
	except:
		pass

	root.mainloop()
