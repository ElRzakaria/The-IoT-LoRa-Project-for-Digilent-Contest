#!/usr/bin/env python3
# author: Guillaume Patrigeon
# date: 10-01-2018

import tkinter as tki
from tkinter import ttk
from tkinter import messagebox
from . import tkinterutils as tku

import time
import threading



# ----------------------------------------------------------------
class Terminal(tku.ScrolledText):
	def __init__(self, parent, pipe, *args, **kwargs):
		tku.ScrolledText.__init__(self, parent, *args, **kwargs)
		self.parent = parent
		self.pipe = pipe

		self.text.tag_config("sel", foreground="black", background="white")
		self.text.tag_config("marker", background="#0F0")
		self.text.insert(tki.INSERT, " ", "marker")

		self.text.mark_set("sentinel", 1.0)
		self.text.mark_gravity("sentinel", tki.RIGHT)

		self.text.bind("<Key>", self.sendChar)
		self.text.bind("<ButtonRelease-1>", self.copy)
		self.text.bind("<Button-3>", self.paste)

		self.flagRun = threading.Event()

		self.flagRun.set()
		self.thread = threading.Thread(target=self.task)
		self.thread.start()


	# --------------------------------
	def destroy(self):
		self.flagRun.clear()
		self.thread.join()
		tku.ScrolledText.destroy(self)


	# --------------------------------
	def sendChar(self, event=None):
		# print(event)

		if self.pipe and len(event.char):
			self.pipe.send(event.char.encode())

		return "break"


	# --------------------------------
	def recvChar(self, s):
		self.text.insert("sentinel", s)
		self.text.see("sentinel")


	# --------------------------------
	def copy(self, event=None):
		try:
			text = self.text.get("sel.first", "sel.last")
		except:
			return

		self.text.clipboard_clear()
		self.text.clipboard_append(text)

		return "break"


	# --------------------------------
	def paste(self, event=None):
		if self.pipe:
			self.pipe.send(self.text.clipboard_get().encode())

		return "break"


	# --------------------------------
	def task(self):
		while self.flagRun.is_set():
			if self.pipe and self.pipe.poll():
				data = self.pipe.recv()
				self.recvChar(data)

			time.sleep(0.05)
