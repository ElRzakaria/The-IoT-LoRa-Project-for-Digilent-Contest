#!/usr/bin/env python3
# author: Guillaume Patrigeon
# update: 11-10-2018

import traceback, errno, time, threading
import multiprocessing as MP

import tkinter as tki
from tkinter import ttk
from tkinter import messagebox
from . import tkinterutils as tku

import serial
from serial.tools import list_ports
import socket



BAUDRATES = [4800, 9600, 19200, 38400, 57600, 115200]
CRCINIT = 34

EXITCODE_OPEN_ERROR = 1
EXITCODE_COMMUNICATION_ERROR = 2
TCP_TIMEOUT = 5



# ----------------------------------------------------------------
class ComProcess(MP.Process):
	def __init__(self, pipe):
		MP.Process.__init__(self, target=self.task, name="Communication")

		# Interface
		self.interface = None
		# Pipe
		self.pipe = pipe
		# State machine current step
		self.step = 0
		# Timeout for message validity
		self.timeout = 0
		# Data buffer
		self.buffer = []


	# Method to override
	def open(self, *args, **kw):
		raise NotImplementedError


	# Method to override
	def close(self, *args, **kw):
		raise NotImplementedError


	# Method to override
	def read(self, *args, **kw):
		raise NotImplementedError


	# Method to override
	def write(self, *args, **kw):
		raise NotImplementedError


	# --------------------------------
	def task(self):
		print("[%d] START" % (self.pid))

		# Open interface
		try:
			self.open()
		except:
			print("[%d] STOP: Unable to open interface" % (self.pid))
			traceback.print_exc()
			# Error code 1: cannot open interface
			exit(EXITCODE_OPEN_ERROR)

		try:
			while True:
				# Leave some time for other processes
				time.sleep(0.002)

				# Send data if waiting
				while self.pipe.poll():
					self.write(self.pipe.recv())

				data = self.read()
				while data:
					self.pipe.send(data)
					# print(data)

					# Check for new data
					data = self.read()

		except:
			self.close()
			print("[%d] STOP: Connection error" % (self.pid))
			traceback.print_exc()
			# Error code 2: error during write or read
			exit(EXITCODE_COMMUNICATION_ERROR)

		self.close()
		print("[%d] STOP: Reach end of process" % (self.pid))
		# It is not possible to finish by this way


# ----------------------------------------------------------------
class ComSerial(ComProcess):
	def __init__(self, port, baudrate, pipe):
		ComProcess.__init__(self, pipe)

		# Settings
		self.port = port
		self.baudrate = baudrate


	# --------------------------------
	def open(self):
		self.interface = serial.Serial(self.port, self.baudrate)
		self.interface.timeout = 0
		self.write = self.interface.write
		self.close = self.interface.close


	# --------------------------------
	def read(self):
		if self.interface.in_waiting:
			data = self.interface.read(1024)
			return data

		return None


# ----------------------------------------------------------------
class ComTCP(ComProcess):
	def __init__(self, address, port, pipe):
		ComProcess.__init__(self, pipe)

		# Settings
		self.address = address
		self.port = port


	# --------------------------------
	def open(self):
		self.interface = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.interface.settimeout(TCP_TIMEOUT)
		self.interface.connect((self.address, self.port))
		self.interface.settimeout(0)
		self.write = self.interface.send
		self.close = self.interface.close


	# --------------------------------
	def read(self):
		try:
			data = self.interface.recv(1024)
			return data

		except socket.error as e:
			if e.args[0] != errno.EWOULDBLOCK:
				# traceback.print_exc()
				raise ConnectionError

		return None



# ----------------------------------------------------------------
class SerialFrame(ttk.Frame):
	def __init__(self, parent, *args, **kw):
		ttk.Frame.__init__(self, parent, *args, **kw)
		self.parent = parent

		# ==== Variables ====
		self.ports = []
		self.portNames = []

		self.portVar = tki.StringVar()
		self.baudrateVar = tki.IntVar()
		self.baudrateVar.set(115200)

		# ==== Inner frames ====
		# List of available ports
		self.cb_Ports = ttk.Combobox(self, textvariable=self.portVar, state="readonly")
		# List of possible baudrates
		self.cb_Baudrates = ttk.Combobox(self, values=BAUDRATES, textvariable=self.baudrateVar, state="readonly", width=8)

		# Add labels and place them into the frame
		ttk.Label(self, text="Serial port:").pack(side="left", padx=5, pady=5)
		self.cb_Ports.pack(side="left", fill="x", expand=True, padx=5, pady=5)
		ttk.Label(self, text="Baudrate:").pack(side="left", padx=5, pady=5)
		self.cb_Baudrates.pack(side="left", padx=5, pady=5)

		# Bind left clic for refresh
		self.cb_Ports.bind("<1>", self.refresh)
		self.refresh()


	# --------------------------------
	def refresh(self, event=None):
		# Delete previous list
		del self.ports[:]
		del self.portNames[:]

		# Build the list of available ports
		for port in list_ports.comports():
			# port[0] is the name, port[1] is the description
			self.ports.append(port[0])
			self.portNames.append(port[0] + ": " + port[1])

		# If no port found, say it
		if len(self.portNames) == 0:
			self.portNames.append(" -- NO SERIAL PORT FOUND -- ")

		# Ensure current selected value is in the list
		if not self.portVar.get() in self.portNames:
			self.portVar.set(self.portNames[0])

		# Refresh the combobox values
		self.cb_Ports.config(values=self.portNames)


	# --------------------------------
	def getComProcess(self, pipe):
		# Check if at least one port is available
		if len(self.ports) == 0:
			messagebox.showwarning("Warning", "No serial port found")
			return None

		# Check if selected value is valid
		if not self.portVar.get() in self.portNames:
			messagebox.showerror("Error", "Invalid port")
			return None

		# Check if baudrate value is valid
		if not self.baudrateVar.get() in BAUDRATES:
			messagebox.showerror("Error", "Invalid baudrate")
			return None

		# Create and return an object with valid settings
		return ComSerial(self.ports[self.portNames.index(self.portVar.get())], self.baudrateVar.get(), pipe)


	# --------------------------------
	def disable(self):
		# Disable graphic elements
		self.cb_Ports.config(state="disabled")
		self.cb_Baudrates.config(state="disabled")


	# --------------------------------
	def enable(self):
		# Enable graphic elements
		self.cb_Ports.config(state="readonly")
		self.cb_Baudrates.config(state="readonly")



# ----------------------------------------------------------------
class TCPFrame(ttk.Frame):
	def __init__(self, parent, *args, **kw):
		ttk.Frame.__init__(self, parent, *args, **kw)
		self.parent = parent

		# --------------------------------
		# Variables
		self.port = None
		self.addressVar = tki.StringVar()

		# --------------------------------
		# Address
		self.en_Address = ttk.Entry(self, textvariable=self.addressVar)
		# Port
		self.en_Port = tku.NumberEntry(self, min=0, max=65535, size=8)
		self.en_Port.variable.set(3000)

		# Add labels and place them into the frame
		ttk.Label(self, text="Host address:").pack(side="left", padx=5, pady=5)
		self.en_Address.pack(side="left", fill="x", expand=True, padx=5, pady=5)
		ttk.Label(self, text="Port:").pack(side="left", padx=5, pady=5)
		self.en_Port.pack(side="left", padx=5, pady=5)


	# --------------------------------
	def getComProcess(self, pipe):
		# Create and return an object with valid settings
		return ComTCP(self.addressVar.get(), self.en_Port.variable.get(), pipe)


	# --------------------------------
	def disable(self):
		# Disable graphic elements
		self.en_Address.config(state="disabled")
		self.en_Port.config(state="disabled")


	# --------------------------------
	def enable(self):
		# Enable graphic elements
		self.en_Address.config(state="normal")
		self.en_Port.config(state="normal")



# ----------------------------------------------------------------
class CommunicationFrame(ttk.LabelFrame):
	def __init__(self, parent, *args, **kw):
		ttk.LabelFrame.__init__(self, parent, *args, **kw)
		self.parent = parent

		# --------------------------------
		# Variables
		self.typeVar = tki.IntVar()
		self.pipe = None
		self.cpipe = None

		# --------------------------------
		# Configuration frame
		self.fr_Serial = SerialFrame(self)
		self.fr_TCP = TCPFrame(self)
		# This frame will change to Serial or TCP frame when clicking on the radio buttons
		self.frame = self.fr_Serial

		# Options frame
		self.fr_Options = ttk.Frame(self)
		# Radio buttons for Serial / TCP selection
		self.rb_Serial = ttk.Radiobutton(self.fr_Options, text="Serial", variable=self.typeVar, value=0, command=self.comTypeSelection)
		self.rb_TCP = ttk.Radiobutton(self.fr_Options, text="TCP", variable=self.typeVar, value=1, command=self.comTypeSelection)
		# Open / Close connection
		self.bt_OpenClose = ttk.Button(self.fr_Options, text="Open", command=self.open, width=12)

		# Build Options frame
		self.rb_Serial.pack(side="left", padx=5, pady=5)
		self.rb_TCP.pack(side="left", padx=5, pady=5)
		self.bt_OpenClose.pack(side="left", padx=5, pady=5)

		# Build main frame (self)
		self.columnconfigure(0, weight=1)
		self.frame.grid(sticky="ew", row=0, column=0)
		self.fr_Options.grid(row=0, column=1)

		# --------------------------------
		# Synchronization flags for internal thread
		self.flagRun = threading.Event()
		self.flagEvent = threading.Event()

		# Synchronization flags for external thread
		self.flagOpen = threading.Event()
		self.flagClosed = threading.Event()
		self.flagClosed.set()

		# Synchronization Lock
		self.lockSubprocess = threading.Lock()

		# Subprocess
		self.subprocess = None

		# Start thread
		self.flagRun.set()
		self.thread = threading.Thread(target=self.task, name="Communication managment")
		self.thread.start()


	# --------------------------------
	def quit(self):
		if self.flagRun.is_set():
			# Inform that task have to finish
			self.flagRun.clear()
			# Close interface
			self.close()
			# Set event flag to ensure that the child thread will end
			self.flagEvent.set()
			# Join the child thread
			self.thread.join()


	# --------------------------------
	def destroy(self):
		self.quit()
		# Normal destoy of this frame
		ttk.Frame.destroy(self)


	# --------------------------------
	def comTypeSelection(self):
		# Used to switch between Serial and TCP
		# Delete previous frame
		self.frame.grid_forget()

		# Replace it by the selected one
		if self.typeVar.get():
			self.frame = self.fr_TCP
		else:
			self.frame = self.fr_Serial

		# Print it
		self.frame.grid(sticky="ew", row=0, column=0)


	# --------------------------------
	def open(self):
		# Lock acces to subprocess object
		self.lockSubprocess.acquire()

		# Normally, subprocess object is None
		if self.subprocess:
			# Release acces to subprocess object
			self.lockSubprocess.release()
			# Request end of the subprocess
			self.close()

		else:
			# Create new pipe
			self.pipe, self.cpipe = MP.Pipe()
			# Get new subprocess definition
			self.subprocess = self.frame.getComProcess(self.cpipe)
			# Release acces to subprocess object
			self.lockSubprocess.release()
			# Inform that an event occured
			self.flagEvent.set()


	# --------------------------------
	def close(self):
		# Lock acces to subprocess object
		self.lockSubprocess.acquire()

		# Try to kill subprocess
		if self.subprocess:
			try:
				if self.subprocess.is_alive():
					self.subprocess.terminate()
			except:
				traceback.print_exc()

		# Release acces to subprocess object
		self.lockSubprocess.release()
		# Inform that an event occured
		self.flagEvent.set()


	# --------------------------------
	def task(self):
		# Run while run flag is set
		while self.flagRun.is_set():
			# Wait an event occur (open or exit)
			self.flagEvent.wait()
			self.flagEvent.clear()

			# Check end of process
			if not self.flagRun.is_set():
				return

			# Lock acces to subprocess object
			self.lockSubprocess.acquire()
			# If object is created and not running
			if self.subprocess and not self.subprocess.is_alive():
				# Set button to close mode and disable settings frame
				self.bt_OpenClose.config(text="Close", command=self.close)
				self.rb_Serial.config(state="disabled")
				self.rb_TCP.config(state="disabled")
				self.frame.disable()

				try:
					# Start subprocess
					self.subprocess.start()
					print("Start of %d" % (self.subprocess.pid))
					# Release acces to subprocess object
					self.lockSubprocess.release()

					# Inform that the interface is open
					self.flagOpen.set()
					self.flagClosed.clear()
					# Wait that the subprocess terminates
					self.subprocess.join()

					# Lock acces to subprocess object
					self.lockSubprocess.acquire()
					ret = self.subprocess.exitcode
					print("End of %d with exitcode %s" % (self.subprocess.pid, str(ret)))

					if ret == EXITCODE_OPEN_ERROR:
						messagebox.showerror("Error", "Unable to open interface")
					elif ret == EXITCODE_COMMUNICATION_ERROR:
						messagebox.showerror("Error", "An error occured and the interface was closed")
				except:
					traceback.print_exc()

				# Inform that the interface is closed
				self.flagOpen.clear()
				self.flagClosed.set()

				# Destroy subprocess object
				self.subprocess = None

				# Set button to open mode and enable settings frame
				if self.flagRun.is_set():
					self.bt_OpenClose.config(text="Open", command=self.open)
					self.rb_Serial.config(state="normal")
					self.rb_TCP.config(state="normal")
					self.frame.enable()

			# Release acces to subprocess object
			self.lockSubprocess.release()



# ----------------------------------------------------------------
if __name__ == "__main__":
	root = tki.Tk()
	a = CommunicationFrame(root, text="Communication frame")
	a.pack(fill="both", expand=True)

	root.title("Communication Frame Test")
	root.mainloop()
