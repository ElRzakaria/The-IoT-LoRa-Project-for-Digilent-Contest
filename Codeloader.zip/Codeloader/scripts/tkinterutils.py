#!/usr/bin/env python3
# author: Guillaume Patrigeon
# update: 01-05-2018

import tkinter as tki
from tkinter import ttk



def int2base(n, b):
	a = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	r = ""

	if n < 0:
		n = -n
		s = "-"
	else:
		s = ""

	while n:
		r += a[n % b]
		n //= b

	if len(r):
		return s + r[::-1]

	return "0"



class ScrolledFrame(ttk.Frame):
	def __init__(self, parent, direction="xy", border=0, *args, **kw):
		ttk.Frame.__init__(self, parent, border=border, *args, **kw)
		self.direction = list(direction)

		canvas = tki.Canvas(self, bd=0, highlightthickness=0)
		self.subframe = ttk.Frame(canvas)
		self.subframe.pack(fill="both")

		if "y" in self.direction:
			yscrollbar = ttk.Scrollbar(self, orient="vertical")
			canvas.config(yscrollcommand=yscrollbar.set)
			yscrollbar.config(command=canvas.yview)
			yscrollbar.pack(fill="y", side="right")
			canvas.yview_moveto(0)

		if "x" in self.direction:
			xscrollbar = ttk.Scrollbar(self, orient="horizontal")
			canvas.config(xscrollcommand=xscrollbar.set)
			xscrollbar.config(command=canvas.xview)
			xscrollbar.pack(fill="x", side="bottom")
			canvas.xview_moveto(0)

		canvas.pack(fill="both")
		canvas.create_window(0, 0, window=self.subframe, anchor="nw")

		def _configure_frame(event):
			width = self.subframe.winfo_reqwidth()
			height = self.subframe.winfo_reqheight()

			canvas.config(width=width, height=height, scrollregion="0 0 %s %s" % (width, height))

		def _yscroll_frame(event):
			canvas.yview_scroll(event.delta // -100, "units")

		def _xscroll_frame(event):
			canvas.xview_scroll(event.delta // -100, "units")

		self.subframe.bind("<Configure>", _configure_frame)
		canvas.bind_all("<MouseWheel>", _yscroll_frame)
		canvas.bind_all("<Shift-MouseWheel>", _xscroll_frame)



class NumberLabel(ttk.Label):
	def __init__(self, parent, variable=None, base=10, justify="right", font=("Consolas", "10"), *args, **kw):
		ttk.Label.__init__(self, parent, justify=justify, font=font, *args, **kw)
		self.base = base

		if variable:
			self.variable = variable
		else:
			self.variable = tki.IntVar()

		self.variable.trace("w", self.refresh)


	def refresh(self, *args):
		self.config(text=int2base(self.variable.get(), self.base))



class NumberEntry(ttk.Entry):
	def __init__(self, parent, size, variable=None, min=None, max=None, base=10, command=None, justify="right", font=("Consolas", "10"), *args, **kw):
		ttk.Entry.__init__(self, parent, width=size, justify=justify, font=font, *args, **kw)
		self.size = size
		self.min = min
		self.max = max
		self.base = base
		self.skip = False
		self.command = command

		if variable:
			self.variable = variable
		else:
			self.variable = tki.IntVar()

		ttk.Style().configure("WrongValue.TEntry", foreground="#F00")

		self.variable.trace("w", self.refresh)
		vcmd = (self.register(self.onValidate), "%P")
		self.config(validate="key", validatecommand=vcmd)


	def refresh(self, *args):
		if not self.skip:
			self.set(self.variable.get())


	def set(self, value):
		if not self.skip:
			self.skip = True
			self.delete(0, tki.END)
			self.insert(0, int2base(value, self.base))
			self.skip = False


	def onValidate(self, new):
		if self.skip:
			return True

		new = new.upper()

		if new == "":
			return True

		try:
			i = int(new, self.base)
		except:
			return False

		if len(new) > self.size:
			return False

		if (self.min is not None and i < self.min) or (self.max is not None and i > self.max):
			self.config(style="WrongValue.TEntry")
		else:
			self.config(style="TEntry")
			self.skip = True
			self.variable.set(i)
			self.skip = False

			if self.command:
				self.command(self)

		return True



class ScrolledText(ttk.Frame):
	def __init__(self, parent, *args, **kw):
		ttk.Frame.__init__(self, parent)

		yscrollbar = ttk.Scrollbar(self, orient="vertical")
		self.text = tki.Text(self, yscrollcommand=yscrollbar.set, *args, **kw)

		yscrollbar.config(command=self.text.yview)

		self.text.pack(fill="both", side="left", expand=True)
		yscrollbar.pack(fill="y", side="right", expand=False)



class ReadOnlyText(ScrolledText):
	def __init__(self, parent, *args, **kwargs):
		ScrolledText.__init__(self, parent, *args, **kwargs)
		self.text.bind("<Key>", lambda event: "break")
		self.text.bind("<Command-c>", lambda event: self.copy)


	def copy(self, event=None):
		self.text.clipboard_clear()
		self.text.clipboard_append(self.text.get("sel.first", "sel.last"))



class ProgressBar(ttk.Frame):
	def __init__(self, parent, variable=None, sticky="W", size=20, color="green", *args, **kw):
		ttk.Frame.__init__(self, parent, *args, **kw)
		self.skip = False
		self.max = 1

		if variable:
			self.variable = variable
		else:
			self.variable = tki.IntVar()

		if sticky in "nN":
			self.direction = 0
			self.canvas = tki.Canvas(self, bd=0, highlightthickness=0, background=color, width=size)
			self.canvas.pack(fill="x", side="top", padx=0, pady=0)

		elif sticky in "sS":
			self.direction = 0
			self.canvas = tki.Canvas(self, bd=0, highlightthickness=0, background=color, width=size)
			self.canvas.pack(fill="x", side="bottom", padx=0, pady=0)

		elif sticky in "eE":
			self.direction = 1
			self.canvas = tki.Canvas(self, bd=0, highlightthickness=0, background=color, height=size)
			self.canvas.pack(fill="y", side="right", padx=0, pady=0)

		elif sticky in "wW":
			self.direction = 1
			self.canvas = tki.Canvas(self, bd=0, highlightthickness=0, background=color, height=size)
			self.canvas.pack(fill="y", side="left", padx=0, pady=0)

		else:
			raise ValueError("'sticky' parameter must be 'N', 'S', 'E' or 'W'")

		self.bind("<Configure>", lambda event: self.refresh(event))
		self.variable.trace("w", self.refresh)


	def setColor(self, color):
		self.canvas.config(background=color)


	def setMax(self, value):
		if value < 1:
			value = 1

		self.max = value
		self.refresh()


	def setValue(self, value):
		self.variable.set(value)


	def refresh(self, *args):
		if not self.skip:
			self.skip = True

			value = self.variable.get()

			if value < 1:
				value = 1
			elif value > self.max:
				value = self.max

			if self.direction:
				self.canvas.config(width=self.winfo_width()*value/self.max)
			else:
				self.canvas.config(height=self.winfo_height()*value/self.max)

			self.skip = False
